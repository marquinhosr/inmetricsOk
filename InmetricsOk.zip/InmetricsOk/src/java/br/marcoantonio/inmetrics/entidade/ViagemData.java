package br.marcoantonio.inmetrics.entidade;

import java.util.Date;
import java.util.Objects;

public class ViagemData {

    private Integer id;
    private Date dateSaida;
    private Date dateChegada;
    private Integer qtdAdulto;
    private Integer qtdCrianca;
    private String localViagem;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    
    
    
    public Date getDateSaida() {
        return dateSaida;
    }

    public void setDateSaida(Date dateSaida) {
        this.dateSaida = dateSaida;
    }

    public Date getDateChegada() {
        return dateChegada;
    }

    public void setDateChegada(Date dateChegada) {
        this.dateChegada = dateChegada;
    }

    public Integer getQtdAdulto() {
        return qtdAdulto;
    }

    public void setQtdAdulto(Integer qtdAdulto) {
        this.qtdAdulto = qtdAdulto;
    }

    public Integer getQtdCrianca() {
        return qtdCrianca;
    }

    public void setQtdCrianca(Integer qtdCrianca) {
        this.qtdCrianca = qtdCrianca;
    }

    public String getLocalViagem() {
        return localViagem;
    }

    public void setLocalViagem(String localViagem) {
        this.localViagem = localViagem;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ViagemData other = (ViagemData) obj;
        if (!Objects.equals(this.id, other.id)) {
            return false;
        }
        return true;
    }

    
    
}
