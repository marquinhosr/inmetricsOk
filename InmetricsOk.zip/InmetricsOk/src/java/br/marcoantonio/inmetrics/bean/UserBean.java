package br.marcoantonio.inmetrics.bean;

import br.marcoantonio.inmetrics.dao.ViagemDataDao;
import br.marcoantonio.inmetrics.entidade.ViagemData;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.SessionScoped;

import java.text.SimpleDateFormat;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;

import org.primefaces.PrimeFaces;
import org.primefaces.event.SelectEvent;

@SessionScoped
@ManagedBean
public class UserBean {

    private ViagemData viagemData = new ViagemData();
    private ViagemDataDao viagemDataDao = new ViagemDataDao();
    private List<ViagemData> viagemDatas = new ArrayList<>();

    public void adicionaViagem() {
        viagemDatas.add(viagemData);
        viagemDataDao.salvar(viagemData);
        viagemData = new ViagemData();

    }

    public void listarBusca() {
        viagemDatas = viagemDataDao.consultarViagem();
    }

    public ViagemData getViagemData() {
        return viagemData;
    }

    public void setViagemData(ViagemData viagemData) {
        this.viagemData = viagemData;
    }

    public List<ViagemData> getViagemDatas() {
        return viagemDatas;
    }

    public void setViagemDatas(List<ViagemData> viagemDatas) {
        this.viagemDatas = viagemDatas;
    }

    public void onDateSelect(SelectEvent event) {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        facesContext.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Date Selected", format.format(event.getObject())));
    }

    public void click() {
        PrimeFaces.current().ajax().update("form:display");
        PrimeFaces.current().executeScript("PF('dlg').show()");
    }

}
