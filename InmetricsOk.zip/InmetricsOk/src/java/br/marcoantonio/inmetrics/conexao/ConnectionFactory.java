package br.marcoantonio.inmetrics.conexao;

import com.sun.org.apache.bcel.internal.generic.RETURN;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConnectionFactory {

    private static Connection conexao;
    private static final String URL_conexao="jdbc:mysql://localhost/banco";
    private static final String USUARIO="root";
    private static final String SENHA="root";// se não tiver senha no banco colocar null

    public static Connection getConexao() {
        if (conexao == null) {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                conexao = DriverManager.getConnection(URL_conexao, USUARIO, SENHA);
            } catch (SQLException ex) {
                Logger.getLogger(ConnectionFactory.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(ConnectionFactory.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        return conexao;
    }
    public static void fechaConexao(){
        if(conexao == null){
            try {
                conexao.close();
                  conexao=null;
            } catch (SQLException ex) {
                Logger.getLogger(ConnectionFactory.class.getName()).log(Level.SEVERE, null, ex);
            }
          
        }
    }

}
