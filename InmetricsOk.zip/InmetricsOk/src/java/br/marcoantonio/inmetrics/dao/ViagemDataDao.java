package br.marcoantonio.inmetrics.dao;

import br.marcoantonio.inmetrics.entidade.ViagemData;
import java.sql.Connection;
//import br.marcoantonio.inmetrics.*;
import br.marcoantonio.inmetrics.conexao.*;
import com.mysql.jdbc.PreparedStatement;
import java.sql.ResultSet;
//import com.sun.istack.logging.Logger;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ViagemDataDao {

    public void salvar(ViagemData viagemData) {
        try {
            Connection conexao = ConnectionFactory.getConexao();

            PreparedStatement ps = (PreparedStatement) conexao.prepareStatement("insert into tabela (campos, campos, campos, campos, campos ) values(?,?,?,?,?)");//passar a query de INSERT
            ps.setString(1, viagemData.getLocalViagem());//passagem dos itens do insert onde cada ? e representada por um numero onde sera atribuido um valor
            ps.setDate(2, new java.sql.Date(viagemData.getDateSaida().getTime()));
            ps.setDate(3, new java.sql.Date(viagemData.getDateChegada().getTime()));
            ps.setInt(4, viagemData.getQtdAdulto());
            ps.setInt(5, viagemData.getQtdCrianca());
            ps.execute();
            ConnectionFactory.fechaConexao();
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(ViagemDataDao.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public List<ViagemData> consultarViagem() {
        try {
            Connection conexao = ConnectionFactory.getConexao();
            PreparedStatement ps = (PreparedStatement) conexao.prepareStatement("select * from tabela");// podendo colocar o select mais detalhado de acordo com a necessidade
            ResultSet resultSet = ps.executeQuery();
            List<ViagemData> viagensDatasBd = new ArrayList<>();
            while (resultSet.next()) {
                ViagemData viagemData = new ViagemData();
                viagemData.setId(resultSet.getInt("id"));
                viagemData.setLocalViagem(resultSet.getString("locaViagem"));
                viagemData.setDateChegada(resultSet.getDate("dateSaida"));
                viagemData.setDateSaida(resultSet.getDate("dateChegada"));
                viagemData.setQtdAdulto(resultSet.getInt("qtdAdulto"));
                viagemData.setQtdAdulto(resultSet.getInt("qtdCrianca"));
                viagensDatasBd.add(viagemData);

            }
            return viagensDatasBd;

        } catch (SQLException ex) {
            Logger.getLogger(ViagemDataDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }

    }

    
}
